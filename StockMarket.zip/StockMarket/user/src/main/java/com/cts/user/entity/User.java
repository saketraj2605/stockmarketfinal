package com.cts.user.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


@Entity
@Table(name = "user")

public class User {

		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		@Column(name = "us_id")
		private int id;

		@NotNull(message = "Email cannot be empty!")
		@Size(max = 255, message = "Email cannot exceed 255 characters!")
		@Pattern(regexp = ".+@.+\\..+", message = "Invalid email address!")
		@Column(name = "us_email")
		private String email;

		@NotNull(message = "Password cannot be empty!")
		@Size(min = 6, max = 100, message = "Password must be 6 to 30 characters!")
		@Column(name = "us_password")
		private String password;

		@Column(name = "us_type")
		private String userType ;

		
		

		@Column(name = "us_confirmed")
		private boolean confirmed;
		
		
		@Column(name = "us_mobileNumber")
		private Long mobileNumber;


		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}
		
		public Long getMobileNumber() {
			return mobileNumber;
		}

		public void setMobileNumber(Long mobileNumber) {
			this.mobileNumber = mobileNumber;
		}
		
		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		public String getUserType() {
			return userType;
		}

		public void setUserType(String userType) {
			this.userType = userType;
		}

		public boolean isConfirmed() {
			return confirmed;
		}

		public void setConfirmed(boolean confirmed) {
			this.confirmed = confirmed;
		}

		public User() {
			super();
		}

		public User(
				@NotNull(message = "Email cannot be empty!") @Size(max = 255, message = "Email cannot exceed 255 characters!") @Pattern(regexp = ".+@.+\\..+", message = "Invalid email address!") String email,
				@NotNull(message = "Password cannot be empty!") @Size(min = 6, max = 100, message = "Password must be 6 to 30 characters!") String password,
				@NotNull(message = "number cannot be empty!") @Size(min = 10, max = 10, message = "atleaste 10 numbers") Long mobileNumber,
				String userType,  boolean confirmed) {
			super();
	
			this.email = email;
			this.password = password;
			this.userType = userType;
			this.mobileNumber = mobileNumber;
			this.confirmed = confirmed;
		}

		public User(
				@NotNull(message = "Email cannot be empty!") @Size(max = 255, message = "Email cannot exceed 255 characters!") @Pattern(regexp = ".+@.+\\..+", message = "Invalid email address!") String email,
				@NotNull(message = "Password cannot be empty!") @Size(min = 6, max = 100, message = "Password must be 6 to 30 characters!") String password) {
			super();
			this.email = email;
			this.password = password;
		}

		@Override
		public String toString() {
			return "User [id=" + id + ", email=" + email + ", password=" + password + ", role=" + userType
					+ ", Number=" + mobileNumber + ", confirmed=" + confirmed + "]";
		}

	}
