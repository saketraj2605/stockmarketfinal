package com.cts.user.repos;

import org.springframework.data.jpa.repository.JpaRepository;


import com.cts.user.entity.User;

public interface UserRepo extends JpaRepository<User, Integer>{
	
	User findByEmailIgnoreCase(String email);
}
