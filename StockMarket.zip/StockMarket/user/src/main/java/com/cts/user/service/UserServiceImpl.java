package com.cts.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.cts.user.entity.ConfirmationToken;
import com.cts.user.entity.User;
import com.cts.user.repos.ConfirmationTokenRepo;
import com.cts.user.repos.UserRepo;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserRepo userRepo;
	
	@Autowired
	private JavaMailSender javaMail;
	
	 @Autowired
	 private ConfirmationTokenRepo confirmationTokenRepository;
	 


	@Override
	public void save(User user)  {
		

		userRepo.save(user);
		ConfirmationToken confirmationToken = new ConfirmationToken(user);

        confirmationTokenRepository.save(confirmationToken);
        SimpleMailMessage mail= new SimpleMailMessage();
		mail.setTo(user.getEmail());
		mail.setSubject("StockMarket Email Confirmation!!");
		mail.setText("To confirm your account, please click here : "
	            +"http://localhost:8991/confirm-account?token="+
				confirmationToken.getConfirmationToken());
		javaMail.send(mail);
		System.out.println("Mail Sent");
		
	}

	@Override
	public void updateUser(User user, String password) {
		user.setPassword(password);
		userRepo.save(user);
	}

	
	
}