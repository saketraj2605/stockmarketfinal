package com.cts.company;


import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import junit.framework.Assert;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = com.cts.stockmarketcharting.StockMarketChartingApplication.class) 
public class StockMarketChartingApplicationTests {

	@Test
	public void contextLoads() throws URISyntaxException {
		RestTemplate restTemplate= new RestTemplate();
		final String baseUrl= "http://localhost:8990/companies";
		URI uri = new URI(baseUrl);
		ResponseEntity<String> responseEntity = restTemplate.getForEntity(uri, String.class);
		Assert.assertEquals(200, responseEntity.getStatusCodeValue());
	}

}