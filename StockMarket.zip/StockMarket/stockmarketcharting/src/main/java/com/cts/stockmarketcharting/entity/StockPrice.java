package com.cts.stockmarketcharting.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "StockPrice")
public class StockPrice {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "StockPrice_id")
	private int id;
	

	@Column(name="Company_code")
	private int companyCode;
	
	@Column(name="stock_exchange")
	private String stockExchange;

	@NotNull(message = "Name cannot be empty!")
	@Column(name = "StockPrice_price")
	private int currentPrice;
	
	@NotNull(message = "Name cannot be empty!")
	@Column(name = "StockPrice_date")
	private Date date;
	
	@NotNull(message = "Name cannot be empty!")
	@Column(name = "StockPrice_time")
	private Date time;

	public int getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(int companyCode) {
		this.companyCode = companyCode;
	}

	public String getStockExchange() {
		return stockExchange;
	}

	public void setStockExchange(String stockExchange) {
		this.stockExchange = stockExchange;
	}

	public int getCurrentPrice() {
		return currentPrice;
	}

	public void setCurrentPrice(int currentPrice) {
		this.currentPrice = currentPrice;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public StockPrice(int companyCode, String stockExchange, int currentPrice, Date date, Date time) {
		super();
		this.companyCode = companyCode;
		this.stockExchange = stockExchange;
		this.currentPrice = currentPrice;
		this.date = date;
		this.time = time;
	}

	public StockPrice() {
		super();
	}
	
	
}
