package com.cts.stockmarketcharting.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cts.stockmarketcharting.entity.StockExchange;

public interface StockExchangeRepo extends JpaRepository<StockExchange, Integer> {

	public StockExchange findStockExchangeByName(String name);
}
