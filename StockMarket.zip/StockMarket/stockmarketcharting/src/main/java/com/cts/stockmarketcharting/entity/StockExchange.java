package com.cts.stockmarketcharting.entity;


import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


@Entity
@Table(name = "StockExchange")
public class StockExchange {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "SE_id")
	private int id;
	
	@NotNull(message = "Name cannot be empty!")
	@Column(name = "SE_name")
	@Size(max = 70, message = "Name cannot exceed 70 characters!")
	private String name;
	
	@NotNull(message = "Name cannot be empty!")
	@Column(name = "SE_about")
	@Size(max = 70, message = "Name cannot exceed 70 characters!")
	private String about;
	
	@NotNull(message = "Name cannot be empty!")
	@Column(name = "SE_address")
	@Size(max = 70, message = "Name cannot exceed 70 characters!")
	private String address;
	
	@NotNull(message = "Name cannot be empty!")
	@Column(name = "SE_remarks")
	@Size(max = 70, message = "Name cannot exceed 70 characters!")
	private String remarks;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public StockExchange(int id, String name, String about, String address, String remarks) {
		super();
		this.id = id;
		this.name = name;
		this.about = about;
		this.address = address;
		this.remarks = remarks;
	}

	public StockExchange() {
		super();
	}
}
