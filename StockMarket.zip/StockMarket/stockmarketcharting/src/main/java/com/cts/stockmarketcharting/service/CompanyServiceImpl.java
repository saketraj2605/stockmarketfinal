package com.cts.stockmarketcharting.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.stockmarketcharting.entity.Company;
import com.cts.stockmarketcharting.repos.CompanyRepo;

@Service
public class CompanyServiceImpl implements CompanyService {
	
	@Autowired
	CompanyRepo companyRepo;

	@Override
	public Company findCompanyByName(String name) {
	   return companyRepo.findCompanyByCompanyName(name);
	}

	@Override
	public List<Company> findAll() {
		
		return companyRepo.findAllActivatedCompany();
	}

	@Override
	public void save(Company company) {
		companyRepo.save(company);
	}

	
	 @Override public void deactivate(Company company) {
		 
		 company.setActive(false);
		 companyRepo.save(company);
		 }

	@Override
	public void updateCEO(Company company, String newCeo) {
		
		company.setCeo(newCeo);
		companyRepo.save(company);
		
	}
	 
	 }
